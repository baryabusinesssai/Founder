document.querySelector(".get-started").addEventListener("click", () => {
  alert("Welcome to Barya Business AI!");
});
function showDashboard() {
  document.getElementById("login").classList.add("hidden");
  document.getElementById("dashboard").classList.remove("hidden");
  document.getElementById("chat").classList.add("hidden");
}

function showChat() {
  document.getElementById("dashboard").classList.add("hidden");
  document.getElementById("chat").classList.remove("hidden");
}

function showFeatureDetails() {
  alert("Feature insights coming soon!");
}

function showMarketplace() {
  alert("Marketplace feature is under development!");
}

function sendMessage() {
  const userMessage = document.getElementById("user-message").value;
  if (userMessage) {
    alert("Message sent to BaryaBot AI: " + userMessage);
    document.getElementById("user-message").value = ""; // Clear the input field
  }
}
